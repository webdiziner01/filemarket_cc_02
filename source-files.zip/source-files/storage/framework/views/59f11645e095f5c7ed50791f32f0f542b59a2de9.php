<nav class="nav">
    <div class="container">
        <div class="nav-left">
            <a href="<?php echo e(route('home')); ?>" class="nav-item is-brand">
                <?php echo e(config('app.name')); ?>

            </a>
        </div>

        <span class="nav-toggle">
            <span></span>
            <span></span>
            <span></span>
        </span>

        <div class="nav-right nav-menu">
            <?php if(auth()->check()): ?>
                <a href="#" class="nav-item" onclick="event.preventDefault(); document.getElementById('logout').submit();">
                    Sign out
                </a>

                <a href="<?php echo e(route('account')); ?>" class="nav-item">
                    Your account
                </a>
                
                <?php if (auth()->check() && auth()->user()->hasRole('admin')): ?>
                    <a href="<?php echo e(route('admin.index')); ?>" class="nav-item">
                        Admin
                    </a>
                <?php endif; ?>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="nav-item">
                    Sign in
                </a>
                    
                <div class="nav-item">
                    <a href="<?php echo e(route('register')); ?>" class="button">
                        Start selling
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</nav>

<form id="logout" action="<?php echo e(route('logout')); ?>" method="POST" class="is-hidden">
    <?php echo e(csrf_field()); ?>

</form>
