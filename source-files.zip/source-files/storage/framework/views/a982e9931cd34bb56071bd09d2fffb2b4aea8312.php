<?php $__env->startComponent('files.partials._file', compact('file')); ?>
    <?php $__env->slot('links'); ?>
        <div class="level">
            <div class="level-left">
                <p class="level-item">
                    <?php echo e($file->isFree() ? 'Free' : '£' . $file->price); ?>

                </p>
                <?php if(!$file->approved): ?>
                    <p class="level-item">
                        Pending approval
                    </p>
                <?php endif; ?>
                <p class="level-item">
                    <?php echo e($file->live ? 'Live' : 'Not live'); ?>

                </p>
                <a href="<?php echo e(route('account.files.edit', $file)); ?>" class="level-item">Make changes</a>
            </div>
        </div>
    <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
