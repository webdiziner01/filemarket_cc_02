<?php $__env->startSection('content'); ?>
    Your file has been rejected
<?php $__env->stopSection(); ?>
<?php echo $__env->make('emails.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>