<article class="media">
    <div class="media-content">
        <div class="content">
            <p>
                <strong>
                    <a href="<?php echo e(route('files.show', $file)); ?>"><?php echo e($file->title); ?></a>
                </strong>
                <br>
                <?php echo e($file->overview_short); ?>

            </p>
        </div>
        <?php echo e(isset($links) ? $links : ''); ?>

    </div>
</article>
