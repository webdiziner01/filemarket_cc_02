<?php if(isset($user)): ?>
    <p>Hi <?php echo e($user->name); ?></p>
<?php else: ?>
    <p>Hi there</p>
<?php endif; ?>

<?php echo $__env->yieldContent('content'); ?>

<p>Thanks,<br><?php echo e(config('app.name')); ?></p>