<article class="message is-primary">
    <div class="message-header">
        <p>We're currently reviewing the following changes</p>
    </div>
    <div class="message-body">
        <div class="content">
            <?php if($approval->title !== $file->title): ?>
                <strong>Title</strong>
                <p><?php echo e($approval->title); ?></p>
            <?php endif; ?>

            <?php if($approval->overview_short !== $file->overview_short): ?>
                <strong>Short overview</strong>
                <p><?php echo e($approval->overview_short); ?></p>
            <?php endif; ?>

            <?php if($approval->overview !== $file->overview): ?>
                <strong>Overview</strong>
                <p><?php echo e($approval->overview); ?></p>
            <?php endif; ?>

            <?php if(($uploads = $file->uploads()->unapproved()->get())->count()): ?>
                <strong>Uploads</strong>
                <?php $__currentLoopData = $uploads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $upload): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p><?php echo e($upload->filename); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
</article>