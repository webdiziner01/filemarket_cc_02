<aside class="menu">
    <p class="menu-label">Manage files</p>
    <ul class="menu-list">
        <li>
            <a href="<?php echo e(route('admin.files.new.index')); ?>">Approve new files</a>
        </li>
        <li>
            <a href="<?php echo e(route('admin.files.updated.index')); ?>">Approve updated files</a>
        </li>
    </ul>
</aside>
