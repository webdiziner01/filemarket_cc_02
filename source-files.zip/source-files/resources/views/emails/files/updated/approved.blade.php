@extends('emails.layouts.default')

@section('content')
    Your file updates have been approved
@endsection