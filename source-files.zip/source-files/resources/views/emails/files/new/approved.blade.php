@extends('emails.layouts.default')

@section('content')
    Your file has been approved
@endsection