@extends('emails.layouts.default')

@section('content')
    Your file has been rejected
@endsection