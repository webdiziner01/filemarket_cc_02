<?php $__env->startSection('account.content'); ?>
    <a href="https://connect.stripe.com/oauth/authorize?response_type=code&state=<?php echo e(session('stripe_token')); ?>&scope=read_write&client_id=<?php echo e(config('services.stripe_connect.key')); ?>">Connect your Stripe account</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('account.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>