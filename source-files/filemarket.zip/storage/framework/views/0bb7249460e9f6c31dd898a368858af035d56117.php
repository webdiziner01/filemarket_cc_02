<?php $__env->startSection('content'); ?>
    <p>Thanks for downloading <strong><?php echo e($sale->file->title); ?></strong> from Filemarket.</p>

    <p><a href="<?php echo e(route('files.download', [$sale->file, $sale])); ?>">Download your file</a></p>

    <p>
        Or, copy and paste this into your browser:<br>
        <?php echo e(route('files.download', [$sale->file, $sale])); ?>

    </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('emails.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>