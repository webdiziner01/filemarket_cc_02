<form action="<?php echo e(route('checkout.free', $file)); ?>" method="post">
    <?php echo e(csrf_field()); ?>

    
    <span class="field has-addons">
        <p class="control">
            <input type="email" name="email" class="input" id="email" required placeholder="you@somewhere.com" value="<?php echo e(old('email')); ?>">
        </p>
        <p class="control">
            <button class="button is-primary">Download for free</button>
        </p>
    </span>
    <?php if($errors->has('email')): ?>
        <p class="help is-danger"><?php echo e($errors->first('email')); ?></p>
    <?php endif; ?>
</form>
