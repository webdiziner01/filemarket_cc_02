<?php $__env->startSection('account.content'); ?>
    <h1 class="title">Sell a file</h1>

    <form action="<?php echo e(route('account.files.store', $file)); ?>" method="post" class="form">
        <?php echo e(csrf_field()); ?>

            
        <div class="field">
            <div id="file" class="dropzone"></div>
            <?php if($errors->has('uploads')): ?>
                <p class="help is-danger"><?php echo e($errors->first('uploads')); ?></p>
            <?php endif; ?>
        </div>

        <div class="field">
            <label for="title" class="label">Title</label>
            <p class="control">
                <input type="text" name="title" id="title" class="input<?php echo e($errors->has('title') ? ' is-danger' : ''); ?>">
            </p>
            <?php if($errors->has('title')): ?>
                <p class="help is-danger"><?php echo e($errors->first('title')); ?></p>
            <?php endif; ?>
        </div>

        <div class="field">
            <label for="overview_short" class="label">Short overview</label>
            <p class="control">
                <input type="text" name="overview_short" id="overview_short" class="input<?php echo e($errors->has('overview_short') ? ' is-danger' : ''); ?>">
            </p>
            <?php if($errors->has('overview_short')): ?>
                <p class="help is-danger"><?php echo e($errors->first('overview_short')); ?></p>
            <?php endif; ?>
        </div>

        <div class="field">
            <label for="overview" class="label">Overview</label>
            <p class="control">
                <textarea name="overview" id="overview" class="textarea<?php echo e($errors->has('overview') ? ' is-danger' : ''); ?>"></textarea>
            </p>
            <?php if($errors->has('overview')): ?>
                <p class="help is-danger"><?php echo e($errors->first('overview')); ?></p>
            <?php endif; ?>
        </div>

        <div class="field">
            <label for="price" class="label">Price (£)</label>
            <p class="control">
                <input type="text" name="price" id="price" class="input<?php echo e($errors->has('price') ? ' is-danger' : ''); ?>">
            </p>
            <?php if($errors->has('price')): ?>
                <p class="help is-danger"><?php echo e($errors->first('price')); ?></p>
            <?php endif; ?>
        </div>

        <div class="field is-grouped">
            <p class="control">
                <button class="button is-primary">Submit</button>
            </p>
            <p>We'll review your file before it goes live.</p>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo $__env->make('files.partials._file_upload_js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('account.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>