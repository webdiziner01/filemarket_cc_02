<?php $__env->startSection('account.content'); ?>
    <h1 class="title">Your files</h1>

    <?php if($files->count()): ?>
        <?php echo $__env->renderEach('account.partials._file', $files, 'file'); ?>
    <?php else: ?>
        <p>You have no files.</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('account.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>