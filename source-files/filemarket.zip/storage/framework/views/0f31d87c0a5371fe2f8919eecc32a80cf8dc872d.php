<?php if(session()->has('success')): ?>
    <div class="notification is-primary">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session()->has('error')): ?>
    <div class="notification is-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>
