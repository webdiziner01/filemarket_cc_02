<?php $__env->startSection('account.content'); ?>
    Account home
<?php $__env->stopSection(); ?>

<?php echo $__env->make('account.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>