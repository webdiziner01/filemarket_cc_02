<form action="<?php echo e(route('checkout.payment', $file)); ?>" method="POST">
    <?php echo e(csrf_field()); ?>

    £<?php echo e($file->price); ?>

    <script
        src="https://checkout.stripe.com/checkout.js"
        class="stripe-button"
        data-key="<?php echo e($file->user->stripe_key); ?>"
        data-amount="<?php echo e($file->price * 100); ?>"
        data-name="<?php echo e($file->title); ?>"
        data-description="<?php echo e($file->overview_short); ?>"
        data-image="https://stripe.com/img/documentation/checkout/marketplace.png"
        data-locale="auto"
        data-currency="gbp"
    >
    </script>
</form>
