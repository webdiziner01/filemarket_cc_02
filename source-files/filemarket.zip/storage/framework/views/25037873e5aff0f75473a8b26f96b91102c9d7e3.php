<?php $__env->startSection('content'); ?>
    <section class="hero is-medium is-info">
        <div class="hero-body">
            <div class="container">
                <?php echo $__env->make('layouts.partials._flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                
                <h3 class="subtitle is-spaced">
                    <strong><?php echo e($file->user->name); ?></strong> is selling
                </h3>
                <h1 class="title is-1 is-spaced"><?php echo e($file->title); ?></h1>
                <h2 class="subtitle">
                    <?php echo e($file->overview_short); ?>

                </h2>
                
                <?php if($file->isFree()): ?>
                    <?php echo $__env->make('files.partials._checkout_form_free', compact('file'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php else: ?>
                    <?php echo $__env->make('files.partials._checkout_form', compact('file'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <section class="section">
        <div class="container">
            <div class="content">
                <div class="columns">
                    <div class="column">
                        <h1 class="title">Overview</h1>
                        <p><?php echo e($file->overview); ?></p>
                    </div>
                    <div class="column">
                        <h1 class="title">What you get</h1>
                        <?php $__currentLoopData = $uploads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $upload): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p><?php echo e($upload->filename); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>