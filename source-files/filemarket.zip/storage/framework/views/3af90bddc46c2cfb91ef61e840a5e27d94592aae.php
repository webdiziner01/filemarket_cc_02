<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.layouts.partials._stats', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <section class="section">
        <div class="container">
            <div class="columns">
                <div class="column is-one-quarter">
                    <?php echo $__env->make('admin.layouts.partials._navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <div class="column">
                    <?php echo $__env->make('layouts.partials._flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->yieldContent('admin.content'); ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>