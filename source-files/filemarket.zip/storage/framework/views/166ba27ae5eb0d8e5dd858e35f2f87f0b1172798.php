<?php $__env->startSection('admin.content'); ?>
    <?php if($files->count()): ?>
        <?php echo $__env->renderEach('admin.partials._file_to_approve', $files, 'file'); ?>
    <?php else: ?>
        <p>There are no new files waiting for approval</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>