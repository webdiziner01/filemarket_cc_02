<script>
    let drop = new Dropzone('#file', {
        createImageThumbnails: false,
        addRemoveLinks: true,
        url: '<?php echo e(route('upload.store', $file)); ?>',
        headers: {
            'X-CSRF-TOKEN': document.head.querySelector('meta[name="csrf-token"]').content
        }
    });

    <?php $__currentLoopData = $file->uploads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $upload): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        drop.emit('addedfile', {
            id: '<?php echo e($upload->id); ?>',
            name: '<?php echo e($upload->filename); ?>',
            size: '<?php echo e($upload->size); ?>'
        });
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    drop.on('success', function (file, response) {
        file.id = response.id
    })

    drop.on('removedfile', function (file) {
        axios.delete('/<?php echo e($file->identifier); ?>/upload/' + file.id).catch(function (error) {
            drop.emit('addedfile', {
                id: file.id,
                name: file.name,
                size: file.size
            })
        })
    })
</script>
