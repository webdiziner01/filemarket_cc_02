<?php

return [
    'sales' => [
        'commission' => 20,
    ]
];