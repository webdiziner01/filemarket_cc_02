@extends('admin.layouts.default')

@section('admin.content')
    Admin home
@endsection
