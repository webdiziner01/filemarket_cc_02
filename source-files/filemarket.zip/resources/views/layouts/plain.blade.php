<!DOCTYPE html>
<html lang="{{ config('app.locale') }}">
    <head>
        @include ('layouts.partials._head')
    </head>
    <body>
        @yield('content')
    </body>
</html>
